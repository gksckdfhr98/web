package com.kdis.demo;

import com.kdis.demo.BoardVO;
import java.util.List;


public interface BoardDAO {
	 public List<BoardVO> list() throws Exception; 
}
