package com.kdis.demo;

import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public interface LoginDAO{
	
	public Integer userJoin(Map<String, Object> paramMap) throws Exception;

	public Integer idCheck(String userId) throws Exception;
}
